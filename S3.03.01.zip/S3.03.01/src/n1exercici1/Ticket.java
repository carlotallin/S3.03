package n1exercici1;

import java.util.ArrayList;

public class Ticket {

	//FIELDS
	private int idTicket;
	private ArrayList <Product> productsList;
	private double totalPrice;
	private String shop;
	
	//CONSTRUCTOR
	public Ticket(int idTicket, String shop) {
		this.idTicket = idTicket;
		productsList = new ArrayList<Product>();
		totalPrice = 0;
		this.shop = shop;
	}
	
	//GETTERS
	public int getIdTicket() {
		return idTicket;
	}
	public ArrayList<Product> getProductsList() {
		return productsList;
	}
	public double getTotalPrice() {
		totalPrice = calculateTotalPrice();
		setTotalPrice(totalPrice);
		return totalPrice;
	}
	public String getShop() {
		return shop;
	}

	//SETTERS
	public void setIdTicket(int idTicket) {
		this.idTicket = idTicket;
	}
	public void setProductList(ArrayList<Product> productList) {
		this.productsList = productList;
	}
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	public void setShop(String shop) {
		this.shop = shop;
	}
	
	//TO STRING
	public String toString() {
		return 	"\n-----------------------------" +
				"\nTICKET ID: " + idTicket +
				"\n\nSHOP: " + shop +
				"\n\nPRODUCTS: " + productsList +
				"\n\nTOTAL SALE: " + calculateTotalPrice() +
				"\n-----------------------------\n";
	}
	
	//METHODS
	public Product SearchProductAndRemoveFromStock(FlowerShop shop, int productId) {
	    Product newProduct = null;

		for (int i=0; i<shop.getTreeStock().size(); i++) {
			if (shop.getTreeStock().get(i).getIdProduct() == productId) { 
				newProduct = shop.getTreeStock().get(i);
				shop.getTreeStock().remove(i);
			}
		}
		for (int i=0; i<shop.getFlowerStock().size(); i++) {
			if (shop.getFlowerStock().get(i).getIdProduct() == productId) {
				newProduct = shop.getFlowerStock().get(i);
				shop.getFlowerStock().remove(i);
			}
		}
		for (int i=0; i<shop.getDecorationStock().size(); i++) {
			if (shop.getDecorationStock().get(i).getIdProduct() == productId) {
				newProduct = shop.getDecorationStock().get(i);
				shop.getDecorationStock().remove(i);
			}
		}
		
		return newProduct;
	}
	public void addProduct (Product product) {
		productsList.add(product);
	}
	public double calculateTotalPrice ( ) {
		double total = 0, price;
		for (int i=0; i<productsList.size(); i++) {	
			price = productsList.get(i).getPrice();
			total += price;
		}	
		return total;
	}
	/* (NO FA FALTA) 
	 * public void printProductsList() {	
		System.out.println("\n*** TICKET (" + idTicket +") PRODUCTS ***");
		for (int i=0; i<productsList.size(); i++) {	
			System.out.println(productsList.get(i).toString());}
	}*/
}
