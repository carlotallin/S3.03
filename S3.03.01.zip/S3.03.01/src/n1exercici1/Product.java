package n1exercici1;

public class Product {
	
	//FIELDS
	protected int idProduct;
	protected double price;
	
	//CONSTRUCTOR
	public Product(int idProduct, double price) {
		this.idProduct = idProduct;
		this.price = price;
	}
	
	//GETTERS AND SETTERS
	public int getIdProduct() {
		return idProduct;
	}
	public double getPrice() {
		return price;
	}
	public void setIdProduct(int idProduct) {
		this.idProduct = idProduct;
	}
	public void setPrice(double price) {
		this.price = price;
	}

	//TO STRING
	public String toString() {
		return "Id product: " + idProduct +
				"Pridce: " + price;
	}
	
}
