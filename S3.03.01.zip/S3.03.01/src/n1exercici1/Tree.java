package n1exercici1;

public class Tree extends Product {

	//FIELDS
	private final String type;
	private double height;

	//CONSTRUCTOR
	public Tree(int id, double price, double height) {
		super(id,price);
		this.type = "Tree";
		this.height = height;
	}
	
	//GETTERS
	public String getType() {
		return type;
	}
	public double getHeight() {
		return height;
	}
	
	//SETTERS
	public void setHeight(double height) {
		this.height = height;
	}
	
	//TO STRING
	@Override
	public String toString() {		
		return "\nType: " + type
				+ "\nId: " + getIdProduct() 
				+ "\nPrice: " + getPrice()
				+ "\nHeight: " + height;	
	}
}
