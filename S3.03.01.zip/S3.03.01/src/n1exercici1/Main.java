package n1exercici1;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Main {
	
	static Scanner sc = new Scanner (System.in); 
	static ArrayList <FlowerShop> shopsList = new ArrayList<>();    

	public static void main(String[] args) {
		
		//SHOP CREATION
		FlowerShop shop = new FlowerShop("MA");
		shopsList.add(shop);
		//PRODUCTS 
		Flower flower  = new Flower(789, 25, "blue");
		Tree tree = new Tree(123, 78, 45);
		PlasticDecoration decoration1 = new PlasticDecoration(1,52.35);
		WoodDecoration decoration2 = new WoodDecoration(2, 56.25);
		//ADD TO SHOP
		shop.addFlower(flower);
		shop.addTree(tree);
		shop.addDecoration(decoration1);
		shop.addDecoration(decoration2);
		
		//MENU
		menu();
			
		}

	// MENU 
	public static void menu() {
		int answerMenu;
		do {
			System.out.println("\n\n- Menu -" + 
				"\n 1. Create new flower shop" + 
				"\n 2. Add tree" + 
				"\n 3. Add flower" + 
				"\n 4. Add decoration" +
				"\n 5. Print Stock" +
				"\n 6. Remove tree" + 
				"\n 7. Remove flower" + 
				"\n 8. Remove decoration" +
				"\n 9. Print Stock quantity" +
				"\n 10. Total Shop total VALUE" +
				"\n 11. Create Sale ticket" + 
				"\n 12. Show old sales" + 
				"\n 13. Total Shop sale WINS" +
				"\n 14. Exit" +
				"\n\n\nSelect option: ");
				answerMenu = sc.nextInt();

			switch (answerMenu) {
				case 1:	createFlowerShop();
						break;
				case 2: addTree();
						break;
				case 3: addFlower();
						break;
				case 4: addDecoration();
						break;
				case 5: printTotalStock();
						break;
				case 6: removeTree();
						break;
				case 7: removeFlower();
						break;
				case 8: removeDecoration();
						break;
				case 9: printStockQuantity();
						break;
				case 10: printFlowerShopValue();
						 break;
				case 11: createSaleTicket();
						 break;
				case 12: showOldSales();
						 break;
				case 13: totalShopWinSales();
						 break;
				case 14: System.out.println("\n** You have exited the site **");
						 System.exit(0);
				default: System.out.println ("** Please, Introduce a valid number. **");
						 break;
			}	
		}
		while (answerMenu<14);
	}
	//QUESTIONAIRES
	public static String askShopName (){  	
		String shopName = null;	
		
		try {
			@SuppressWarnings("resource")
			Scanner sc = new Scanner (System.in);
			System.out.println("\nWrite the shop's name:");
			shopName = sc.nextLine();
			shopName = shopName.toUpperCase();
		} catch (Exception e) {
			System.out.println("\n *** There has been an error, please try again ***");
			askShopName();
		}
		
    	return shopName;
    }
    public static int askId (){
    	int id = 0;
    	
    	try { 		
    		@SuppressWarnings("resource")
			Scanner sc = new Scanner (System.in);
    		System.out.println("\nWrite the product's id:");
            id = sc.nextInt();
		} catch (Exception e) {
			System.out.println("\n *** Invalid number, insert a again the ID ***");
			askId();
		}
    	
        return id;       
    }
    public static double askPrice() {
    	double price = 0;
    	
    	try {
			@SuppressWarnings("resource")
			Scanner sc = new Scanner (System.in);
    		System.out.println("\nWrite its price:");
    		price = sc.nextDouble();
		} catch (Exception e) {
			System.out.println("\n *** Invalid number, insert again the PRICE ***");
			askPrice();
		}
    	
		return price;
    }
    
    //SHOP INDEX
    public static int searchShopIndex (String shopName) {
        int index = 0;
        int foundIndex =-1;
        boolean findShop = false;
        
        while (!findShop && index < shopsList.size()){
            if(shopsList.get(index).getNameShop().equals(shopName)){
            	findShop = true;
                foundIndex = index;}
            index++; 
        }
        
        return foundIndex;  
    }

    //CREATE SHOP
	public static void createFlowerShop() {	
		FlowerShop newFlowerShop = new FlowerShop(askShopName()); 
		shopsList.add(newFlowerShop);
		System.out.println("\n* You have created a NEW SHOP *");
	}
	
	//ADD ITEM TO THE SHOP
	public static void addTree() {		
		double heightTree;
		
		try {
			System.out.println("\nWrite the tree's height:");
			heightTree = sc.nextDouble();
			
			Tree newTree = new Tree(askId(),heightTree,askPrice());
			int indexShop = searchShopIndex(askShopName());
			
			try {
				shopsList.get(indexShop).addTree(newTree);
			} catch (Exception e) {
				System.out.println("\n *** This store it's NOT in our database, create a new one if needed ***");
			}
		} catch (Exception e) {
			System.out.println("\n *** Invalid number, try again ***");
			addTree();
		}
	}
	public static void addFlower() {
		String color;
		
		try {
			System.out.println("\nWrite the flower's color:");
			color = sc.nextLine();
	
			Flower newFlower = new Flower(askId(),askPrice(), color);
			int indexShop = searchShopIndex(askShopName());
			
			try {
				shopsList.get(indexShop).addFlower(newFlower);		
			} catch (Exception e) {
				System.out.println("\n *** This store it's NOT in our database, create a new one if needed ***");
			}
		} catch (Exception e) {
			System.out.println("\n *** Invalid number, try again ***");
			addFlower();
		}	
	}
	public static void addDecoration() {
		int materialAnswer;
				
		try{
			System.out.println("\nIs it a plastic(1) or wood(2) decoration, introduce a number (1-2):");
			materialAnswer = sc.nextInt();
		
			int indexShop = searchShopIndex(askShopName());
			if (materialAnswer ==1 ) {
				PlasticDecoration newDecoration = new PlasticDecoration(askId(),askPrice());
				shopsList.get(indexShop).addDecoration(newDecoration);		
			}
			else if (materialAnswer == 2) {
				WoodDecoration newDecoration = new WoodDecoration(askId(), askPrice());
				shopsList.get(indexShop).getDecorationStock().add(newDecoration);			
			}
			else {System.out.println("\n* Invalid number *");
				addDecoration();}	
		} catch (Exception e) {
			System.out.println("\n *** Invalid input, try again ***");
			addDecoration();
		}	
	}
	
	//PRINT STOCK
	public static void printTotalStock() {	
		int indexShop;
		
		try {
			indexShop = searchShopIndex(askShopName());	
			FlowerShop shop = shopsList.get(indexShop);
			System.out.println("\n * TREE STOCK *" + shop.getTreeStock().toString());
			System.out.println("\n * FLOWER STOCK *" + shop.getFlowerStock().toString());
			System.out.println("\n * DECORATION STOCK *" + shop.getDecorationStock().toString());
		} catch (Exception e) {
			System.out.println("\n*** This store it's NOT in our database, create a new one if needed ***");
		}
	}
	
	//REMOVE ITEMS
	public static void removeTree() {
		int indexShop;

		try {
			indexShop = searchShopIndex(askShopName());	
			shopsList.get(indexShop).removeTree(askId());
		}catch (Exception e) {
			System.out.println("\n*** This store it's NOT in our database, create a new one if needed ***");
		}
	}
	public static void removeFlower() {
		int indexShop;
		
		try {
			indexShop = searchShopIndex(askShopName());	
			shopsList.get(indexShop).removeFlower(askId());
		}catch (Exception e) {
			System.out.println("\n*** This store it's NOT in our database, create a new one if needed ***");
		}
	}
	public static void removeDecoration() {
		int indexShop;
		
		try {
			indexShop = searchShopIndex(askShopName());	
			shopsList.get(indexShop).removeDecoration(askId());
		}catch (Exception e) {
			System.out.println("\n*** This store it's NOT in our database, create a new one if needed ***");
		}
	}
	
	//STOCK QUANTITY
	public static void printStockQuantity() {	
		int indexShop;
		
		try {
			indexShop = searchShopIndex(askShopName());	
			System.out.println(shopsList.get(indexShop).printStockQuantity());
		}catch (Exception e) {
			System.out.println("\n*** This store it's NOT in our database, create a new one if needed ***");
		}
	}	
	
	//SHOP VALUE
	public static void printFlowerShopValue() {
		int indexShop;
		
		try {
			indexShop = searchShopIndex(askShopName());	
			double totalValue = shopsList.get(indexShop).getTotalValue();
			String shopName = shopsList.get(indexShop).getNameShop();
			System.out.println("\n* TOTAL VALUE of " + shopName + ": " + totalValue + "€. *");
		}catch (Exception e) {
			System.out.println("\n*** This store it's NOT in our database, create a new one if needed ***");
		}
	}

	//SALES TICKET
	public static void createSaleTicket() {
		String shopName = askShopName();
		int indexShop = searchShopIndex(shopName);
		
		try {
			Random randomId = new Random();
			FlowerShop shop = shopsList.get(indexShop);
			int idTicket = randomId.nextInt(1000);
			int answer;
			Ticket newTicket = new Ticket(idTicket,shopName);
			
			do {System.out.println("\nIntroduce the ID of the product you want to ADD or END the ticket by writting(0):" );
				answer = sc.nextInt();
				if (answer != 0) {
					Product product = newTicket.SearchProductAndRemoveFromStock(shop, answer);
					if (product == null) {
						System.out.println("* This product is not in our database, please check again *");
					}
					else {newTicket.addProduct(product);
					
						  System.out.println("\nYou have added: " + product.toString());
				    }	 
				}
			} 
			while (answer != 0);
			
			//Add ticket to a list
			shop.getTicketList().add(newTicket);
			System.out.println("\n* NEW TICKET CREATED: *" + newTicket.toString());	
			
		}catch (Exception e) {
			System.out.println("\n*** This store it's NOT in our database, create a new one if needed ***");
		}
		
		
	}

	//SHOW OLD TICKETS   
	public static void showOldSales() {
		int indexShop = searchShopIndex(askShopName());	
		try {
			ArrayList <Ticket> ticketList = shopsList.get(indexShop).getTicketList();
			System.out.println("\n * TICKETS *");
			System.out.println(ticketList.toString());
		} catch (Exception e) {
			System.out.println("\n*** This store it's NOT in our database, create a new one if needed ***");
		}

	}
	
	//TOTAL WIN SALES
	public static void totalShopWinSales() {
		int indexShop = searchShopIndex(askShopName());	
		double totalSale = 0;
		double ticketSale;
		
		try {
			ArrayList <Ticket> ticketList = shopsList.get(indexShop).getTicketList();
			for (int i = 0; i<ticketList.size(); i++) {
				ticketSale = ticketList.get(i).getTotalPrice();
				totalSale += ticketSale;
			}
			System.out.println("\n* TOTAL SALE of " + shopsList.get(indexShop).getNameShop() + ": " + totalSale + "€ *");
		} catch (Exception e) {
			System.out.println("\n*** This store it's NOT in our database, create a new one if needed ***");	
		}
	}
	
}
		
	
