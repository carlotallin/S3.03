package n1exercici1;

import java.util.ArrayList;

public class FlowerShop {

	//FIELDS
	private String nameShop;
	private ArrayList <Tree> treeStock;
	private ArrayList <Decoration> decorationStock;
	private ArrayList <Flower> flowerStock;
	private ArrayList <Ticket> ticketList;
	private double totalValue;
	
	//CONSTRUCTOR
	public FlowerShop(String nameShop) {
		this.nameShop = nameShop;
		this.treeStock = new ArrayList<Tree>();
		this.decorationStock = new ArrayList<Decoration>();
		this.flowerStock = new ArrayList<Flower>();
		this.ticketList  = new ArrayList<Ticket>();
		this.totalValue = 0;
	}
	
	//GETTERS
	public String getNameShop() {
		return nameShop;
	}
	public ArrayList<Decoration> getDecorationStock() {
		return decorationStock;
	}
	public ArrayList<Flower> getFlowerStock() {
		return flowerStock;
	}
	public ArrayList<Tree> getTreeStock() {
		return treeStock;
	}
	public ArrayList<Ticket> getTicketList() {
		return ticketList;
	}
	public double getTotalValue() {
		totalValue = shopValue();
		return totalValue;
	}
	
	//SETTERS
	public void setNameShop(String nameShop) {
		this.nameShop = nameShop;
	}
	public void setTreeStock(ArrayList<Tree> treeStock) {
		this.treeStock = treeStock;
	}
	public void setDecorationStock(ArrayList<Decoration> decorationStock) {
		this.decorationStock = decorationStock;
	}
	public void setFlowerStock(ArrayList<Flower> flowerStock) {
		this.flowerStock = flowerStock;
	}
	public void setTicketList(ArrayList<Ticket> ticketList) {
		this.ticketList = ticketList;
	}
	public void setTotalValue(double totalValue) {
		this.totalValue = totalValue;
	}

	
	//METHODS	
	//ADD ITEMS
	public void addTree(Tree newTree) {
		treeStock.add(newTree);	
		System.out.println("\n* You have added " + newTree.getIdProduct() + "(id) tree to " + nameShop + "'s shop *");

	}
	public void addFlower(Flower newFlower) {
		flowerStock.add(newFlower);	
		System.out.println("\n* You have added " + newFlower.getIdProduct() + "(id) flower to " + nameShop + "'s shop *");
	}
	public void addDecoration(Decoration newDecoration) {
		decorationStock.add(newDecoration);	
		System.out.println("\n* You have added " + newDecoration.getIdProduct() + "(id) decoration to " + nameShop + "'s shop *");

	}	
	public void addTicket (Ticket ticket) {
		ticketList.add(ticket);
	}
	
	
	//REMOVE ITEMS
	public void removeTree(int id) {
		boolean found = false;
		for (int i=0; i<treeStock.size(); i++){
			if (treeStock.get(i).getIdProduct() == id){
				found = true;
				treeStock.remove(i);
				System.out.println("\n *** Product with ID(" + id + ") erased ***");
			}	
		}
		if (found == false) {
			System.out.println("\n *** There's NOT a tree with ID(" + id + ") in our database ***");
		}
	}
	public void removeFlower(int id) {
		boolean found = false;
		for (int i=0; i<flowerStock.size(); i++){
			if (flowerStock.get(i).getIdProduct() == id){
				found = true;
				flowerStock.remove(i);
				System.out.println("\n *** Product with ID(" + id + ") erased ***");
			}	
		}
		if (found == false) {
			System.out.println("\n *** There's NOT a flower with ID(" + id + ") in our database ***");
		}
	}
	public void removeDecoration(int id) {
		boolean found = false;
		for (int i=0; i<decorationStock.size(); i++){
			if (decorationStock.get(i).getIdProduct() == id){
				found = true;
				decorationStock.remove(i);
				System.out.println("\n *** Product with ID(" + id + ") erased ***");
			}
		}
		if (found == false) {
			System.out.println("\n *** There's NOT a decoration with ID(" + id + ") in our database ***");
		}
	}
	
	//PRINT STOCK QUANTITY
	public String printStockQuantity() {	
		return				"\n* STOCK *" +
							"\nTrees : " + treeStock.size() + 
							"\nFlowers : " + flowerStock.size() +
							"\nDecorations : " + decorationStock.size();
	}
	
	//SHOP VALUE
	public double shopValue() {
		double sumPrices = 0;
		
		for (int i=0; i<treeStock.size(); i++) {
			double price = treeStock.get(i).getPrice();
			sumPrices += price;
		}
		for (int i=0; i<flowerStock.size(); i++) {
			double price = flowerStock.get(i).getPrice();
			sumPrices += price;
		}
		for (int i=0; i<decorationStock.size(); i++) {
			double price = decorationStock.get(i).getPrice();
			sumPrices += price;
		}
		return sumPrices;
	}

	//TO STRING		
	public String toString () {
		setTotalValue(shopValue());
		return 	"\n\n*** SHOP INFO *** " +
				"\n\n- Shop name - \n" + nameShop +
				"\n\n - Tree Stock - \n" + treeStock +
				"\n\n - Flower Stock - \n" + flowerStock +
				"\n\n - Decoration Stock - \n " + decorationStock +
				"\n\n - Ticket list - \n" + ticketList +
				"\n\n - TOTAL VALUE - \n" + totalValue + "€";
	}
}
