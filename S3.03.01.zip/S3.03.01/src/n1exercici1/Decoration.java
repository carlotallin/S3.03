package n1exercici1;

public class Decoration extends Product{

	//FIELDS
	protected final String type;
	
	//GETTER
	public String getType() {
		return type;
	}
	
	//CONSTRUCTOR
	public Decoration(int id, double price) {
		super(id, price);
		this.type= "Decoration";
	}
	
	//TO STRING
	@Override
	public String toString() {
		return "\nType: " + type
				+ "\nId: " + getIdProduct() 
				+ "\nPrice: " + getPrice();
	}
}
