package n1exercici1;

public class PlasticDecoration extends Decoration {

	//FIELDS
	private final String material;
	
	//CONSTRUCTOR
	public PlasticDecoration(int id, double price) {
		super(id, price);
		material = "Plastic";
	}

	//GETTER
	public String getMaterial() {
		return material;
	}

	//TO STRING
	@Override
	public String toString() {	
		return "\nType: " + getType()
				+ "\nId: " + getIdProduct() 
				+ "\nPrice: " + getPrice()
				+ "\nMaterial: " + material;	
	}
	
}
